# Important files to maintain and managed during upgrades or changes. The following files or directories have been added to extend functionality or modified. 
- configs/*
- zsh-maia-prompt
- redhat-zsh-config
- zshrc
- plugins/fzf 
